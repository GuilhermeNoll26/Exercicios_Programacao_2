package Controller;

import Model.Disciplina;
import Model.Professor;
import Persistencia.DisciplinaDao;
import Persistencia.ProfessorDao;

/**
 * Aluno: Tiago Funk.
 * @author 5105011610
 */
public class Executar {
    
    public static void main(String[] args) {
        new ProfessorDao().Criar(new Professor(15, "Brenda"));
        
        new DisciplinaDao().Criar(new Disciplina(56, "Algebra"));
    }
}
