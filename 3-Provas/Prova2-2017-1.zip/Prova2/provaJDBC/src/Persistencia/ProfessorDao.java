package Persistencia;

import Model.Professor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ProfessorDao {
    
     public void Criar(Professor p) {
        Connection c = ConexaoJDBC.abreConexao();
        PreparedStatement ps = null;

        try {
            ps = c.prepareStatement("insert into tbl_professor values(?, ?);");

            ps.setLong(1, p.getId());
            ps.setString(2, p.getNome());

            ps.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar no banco de dados." + ex);
        }
    }
}
