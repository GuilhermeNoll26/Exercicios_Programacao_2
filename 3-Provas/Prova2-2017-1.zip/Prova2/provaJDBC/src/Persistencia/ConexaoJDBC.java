package Persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoJDBC {
    
    private static final String DRIVER = "org.postgresql.Driver";
    private static final String URL = "jdbc:postgresql://localhost:5432/Tiago";
    private static final String USER = "postgres";
    private static final String PASSWORD = "root";
    
    public static Connection abreConexao(){
        
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao executar sql " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException("Classe não encontrada" + ex.getMessage());
        }
    }
}
