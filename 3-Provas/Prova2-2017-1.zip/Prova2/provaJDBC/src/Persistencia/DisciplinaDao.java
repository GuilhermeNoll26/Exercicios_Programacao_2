package Persistencia;

import Model.Disciplina;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DisciplinaDao {
    
     public void Criar(Disciplina d) {
        Connection c = ConexaoJDBC.abreConexao();
        PreparedStatement ps = null;

        try {
            ps = c.prepareStatement("insert into tbl_disciplina values(?, ?);");

            ps.setLong(1, d.getId());
            ps.setString(2, d.getNome());

            ps.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar no banco de dados." + ex);
        }
    }
}
