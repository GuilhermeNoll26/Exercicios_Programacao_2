--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

-- Started on 2017-06-28 19:59:22

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12387)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2163 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 191 (class 1259 OID 16434)
-- Name: aluno; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE aluno (
    id bigint NOT NULL,
    nome character varying(255)
);


ALTER TABLE aluno OWNER TO postgres;

--
-- TOC entry 189 (class 1259 OID 16424)
-- Name: curso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE curso (
    id bigint NOT NULL,
    nome character varying(255)
);


ALTER TABLE curso OWNER TO postgres;

--
-- TOC entry 190 (class 1259 OID 16429)
-- Name: sequence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE sequence (
    seq_name character varying(50) NOT NULL,
    seq_count numeric(38,0)
);


ALTER TABLE sequence OWNER TO postgres;

--
-- TOC entry 187 (class 1259 OID 16405)
-- Name: tbl_disciplina; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tbl_disciplina (
    pk_id integer NOT NULL,
    chr_nome character varying
);


ALTER TABLE tbl_disciplina OWNER TO postgres;

--
-- TOC entry 188 (class 1259 OID 16408)
-- Name: tbl_disciplina_pk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_disciplina_pk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tbl_disciplina_pk_id_seq OWNER TO postgres;

--
-- TOC entry 2164 (class 0 OID 0)
-- Dependencies: 188
-- Name: tbl_disciplina_pk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_disciplina_pk_id_seq OWNED BY tbl_disciplina.pk_id;


--
-- TOC entry 186 (class 1259 OID 16396)
-- Name: tbl_professor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tbl_professor (
    pk_id integer NOT NULL,
    chr_nome character varying
);


ALTER TABLE tbl_professor OWNER TO postgres;

--
-- TOC entry 185 (class 1259 OID 16394)
-- Name: tbl_professor_pk_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tbl_professor_pk_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tbl_professor_pk_id_seq OWNER TO postgres;

--
-- TOC entry 2165 (class 0 OID 0)
-- Dependencies: 185
-- Name: tbl_professor_pk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tbl_professor_pk_id_seq OWNED BY tbl_professor.pk_id;


--
-- TOC entry 2022 (class 2604 OID 16410)
-- Name: tbl_disciplina pk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_disciplina ALTER COLUMN pk_id SET DEFAULT nextval('tbl_disciplina_pk_id_seq'::regclass);


--
-- TOC entry 2021 (class 2604 OID 16399)
-- Name: tbl_professor pk_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_professor ALTER COLUMN pk_id SET DEFAULT nextval('tbl_professor_pk_id_seq'::regclass);


--
-- TOC entry 2156 (class 0 OID 16434)
-- Dependencies: 191
-- Data for Name: aluno; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY aluno (id, nome) FROM stdin;
2	Douglas
1	Tiago
\.


--
-- TOC entry 2154 (class 0 OID 16424)
-- Dependencies: 189
-- Data for Name: curso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY curso (id, nome) FROM stdin;
1	Eng Software
2	Eng Sanitaria
\.


--
-- TOC entry 2155 (class 0 OID 16429)
-- Dependencies: 190
-- Data for Name: sequence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY sequence (seq_name, seq_count) FROM stdin;
SEQ_GEN	0
\.


--
-- TOC entry 2152 (class 0 OID 16405)
-- Dependencies: 187
-- Data for Name: tbl_disciplina; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tbl_disciplina (pk_id, chr_nome) FROM stdin;
58	Programação
23	Cálculo
56	Algebra
\.


--
-- TOC entry 2166 (class 0 OID 0)
-- Dependencies: 188
-- Name: tbl_disciplina_pk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tbl_disciplina_pk_id_seq', 1, false);


--
-- TOC entry 2151 (class 0 OID 16396)
-- Dependencies: 186
-- Data for Name: tbl_professor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tbl_professor (pk_id, chr_nome) FROM stdin;
1	Tiago
2	Farah
15	Brenda
\.


--
-- TOC entry 2167 (class 0 OID 0)
-- Dependencies: 185
-- Name: tbl_professor_pk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tbl_professor_pk_id_seq', 1, false);


--
-- TOC entry 2032 (class 2606 OID 16438)
-- Name: aluno aluno_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY aluno
    ADD CONSTRAINT aluno_pkey PRIMARY KEY (id);


--
-- TOC entry 2028 (class 2606 OID 16428)
-- Name: curso curso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY curso
    ADD CONSTRAINT curso_pkey PRIMARY KEY (id);


--
-- TOC entry 2030 (class 2606 OID 16433)
-- Name: sequence sequence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY sequence
    ADD CONSTRAINT sequence_pkey PRIMARY KEY (seq_name);


--
-- TOC entry 2026 (class 2606 OID 16418)
-- Name: tbl_disciplina tbl_disciplina_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_disciplina
    ADD CONSTRAINT tbl_disciplina_pkey PRIMARY KEY (pk_id);


--
-- TOC entry 2024 (class 2606 OID 16404)
-- Name: tbl_professor tbl_professor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tbl_professor
    ADD CONSTRAINT tbl_professor_pkey PRIMARY KEY (pk_id);


-- Completed on 2017-06-28 19:59:22

--
-- PostgreSQL database dump complete
--

