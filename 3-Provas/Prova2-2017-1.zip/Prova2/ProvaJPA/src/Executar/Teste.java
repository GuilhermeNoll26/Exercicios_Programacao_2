package Executar;

import Model.Aluno;
import Model.Curso;
import Persistencia.AlunoJpaController;
import Persistencia.CursoJpaController;

/**
 * Aluno: Tiago Funk.
 * @author 5105011610
 */
public class Teste {
    
    public static void main(String[] args) {
        
        new AlunoJpaController().create(new Aluno( (long) 1, "Tiago"));
        
        new CursoJpaController().create(new Curso((long) 2, "Eng Sanitaria"));
    }
}
