/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TIAGOQuestao03;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author 5105011610
 */
public class Controlador {
    
    private Tela t;

    public Controlador() {
        t = new Tela();
        t.setVisible(true);
        
        t.addSomaListener(new SomaListener());
        t.addMediaListener(new MediaListener());
    }
    
    class SomaListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            double soma = t.getNUm1() + t.getNum2();
            t.mostrarMensagem("Soma dos números: " + soma);
        }
        
    }
    
    
    class MediaListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            double media = (t.getNUm1() + t.getNum2()) / 2;
            t.mostrarMensagem("Média dos numeros: " + media);
        }
        
    }
}
