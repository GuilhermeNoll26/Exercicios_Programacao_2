/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TIAGOQuestao01;

/**
 *
 * @author 5105011610
 */
public class Tabuleiro {
    
    private static String[][] tabuleiro = new String[8][8];

    public Tabuleiro() {
        for(int i = 0; i < tabuleiro.length; i++){
            for(int j = 0; j < tabuleiro[i].length; j++){
                tabuleiro[i][j] = "x  ";
            }
        }
    }
    
    public void limparPosicaoAntiga(int x, int y){
        tabuleiro[x][y] = "X  ";
    }
    
    public void posicionaPeca(String nomePeca, int x, int y){
        if(x == 8){
            System.out.println("\n\n\nPosição do tabuleiro inválida para o " + nomePeca + "!!\n\n\n");
        }else if (y == 8){
            System.out.println("\n\n\nPosição do tabuleiro inválida para o " + nomePeca + "!!\n\n\n");
        }else{
            tabuleiro[x][y] = nomePeca + " ";
        }
    }
    
    public String imprimirTabuleiro(){
        String mostrar = "";
        for(int i = 0; i < tabuleiro.length; i++){
            for(int j = 0; j < tabuleiro[i].length; j++){
                mostrar += tabuleiro[i][j] + " ";
            }
            mostrar += "\n";
        }
        return mostrar;
    }
}
