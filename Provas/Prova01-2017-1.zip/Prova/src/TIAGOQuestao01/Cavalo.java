/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TIAGOQuestao01;

/**
 *
 * @author 5105011610
 */
public class Cavalo {

    private String nome;
    private int x;
    private int y;
    private Tabuleiro t;

    public Cavalo(Tabuleiro t) {
        this.t = t;
    }

    public void mover(int x, int y) {
        
        this.x = x;
        this.y = y;
        t.posicionaPeca(nome, x, y);
    }

    public int[] getPosicao() {
        int[] xy = new int[2];
        xy[0] = this.x;
        xy[1] = this.y;
        return xy;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
