/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TIAGOQuestao01;

/**
 *
 * @author 5105011610
 */
public class Principal {
 
    public static void main(String[] args) {
        Tabuleiro t = new Tabuleiro();
        System.out.println(t.imprimirTabuleiro());
        
        Cavalo c1 = new Cavalo(t);
        c1.setNome("c1");
        c1.mover(0, 1);
        
        Cavalo c2 = new Cavalo(t);
        c2.setNome("c2");
        c2.mover(0, 6);
        
        Cavalo c3 = new Cavalo(t);
        c2.setNome("c3");
        c2.mover(7, 1);
        
        Cavalo c4 = new Cavalo(t);
        c2.setNome("c4");
        c2.mover(7, 6);
        
        System.out.println(t.imprimirTabuleiro());
        
        c1.mover(2, 2);
        c2.mover(1, 8);
        
        System.out.println(t.imprimirTabuleiro());
    }
}
